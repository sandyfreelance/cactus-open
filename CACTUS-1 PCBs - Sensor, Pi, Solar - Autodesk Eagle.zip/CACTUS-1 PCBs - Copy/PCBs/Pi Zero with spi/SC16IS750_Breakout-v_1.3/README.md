SC16IS750 Breakout
=================

[![SC16IS750 Breakout](https://dlnmh9ip6v2uc.cloudfront.net//images/products/9/9/8/1/09981-01b.jpg)  
*Breakout Board for SC16IS750 I2C/SPI-to-UART IC (BOB-09981)*](https://www.sparkfun.com/products/9981)

The SC16IS750 converts I<sup>2</sup>C or SPI serial signals to a single-channel, high-performance UART.

Repository Contents
-------------------
* **/Hardware** - All Eagle design files (.brd, .sch)

License Information
-------------------
The hardware is released under [Creative Commons Share-alike 3.0](http://creativecommons.org/licenses/by-sa/3.0/).  
