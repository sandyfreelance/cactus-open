This is the PCB for the Adafruit 12 and 16 bit I2C ADC's with PGA
Format is EagleCAD schematic and board layout

For more details, check out the product page at

-----> http://adafruit.com/products/1083
-----> http://adafruit.com/products/1085

Adafruit invests time and resources providing this open source design, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Designed by Adafruit Industries.  
Creative Commons Attribution, Share-Alike license, check license.txt for more information
All text above must be included in any redistribution